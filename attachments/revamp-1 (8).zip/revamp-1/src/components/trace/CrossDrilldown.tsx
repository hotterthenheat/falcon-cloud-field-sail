/*
==================================================
  SLAYER TERMINAL - THE CROSS CARD (components/trace/CrossDrilldown.tsx)
  One dark-pool cross, in the Live Tape's print
  card grammar (2026-10-19; the partner through
  Noah: the dark pool "should look similar to the
  live tape page … a more detailed description when
  the user clicks on a specific one"): the head
  band with the name, the price, the shares, the
  dollars, the venue, the time and the read's tag;
  the figures as dot-leader facts; the read as the
  sentence; THE SEQUENCE — the same name's other
  crosses on the tape, previous and next in the
  head; THE TAPE — the name's crosses through the
  day as bars in their read's ink against the
  stock's price, with the name's shelves drawn
  across it, where the shelves do their best work.
  The doors: Bookmark (the Tracker's mark, the
  same store the tape's prints use), Chart (Terrain
  at the shelf), Weigh it.
==================================================
*/
import { useEffect, useMemo, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bookmark, ChevronLeft, ChevronRight, Crosshair, Scale } from 'lucide-react';
import { createChart, HistogramSeries, LineSeries, LineStyle, type IChartApi, type UTCTimestamp } from 'lightweight-charts';
import Modal from '../ui/Modal';
import Fact from '../ui/Fact';
import CompanyLogo from '../ui/CompanyLogo';
import GradeMeter from '../ui/GradeMeter';
import Simulator from '../../core/simulator';
import { nyClock } from '../../core/nyTime';
import { fmtUsd } from '../../data/gex';
import { gradeOfConviction, gradeOfPosture, POSTURE_WORD } from '../../data/darkpool';
import { crossKey, useWatch, watchedCross } from '../../context/WatchContext';
import { readToken, useResolvedTheme } from '../../theme/theme';
import { dayChartOptions, daySurface } from '../gex/dayChart';
import type { DarkPoolIntent, DarkPoolPrint, DarkPoolView, LevelRole } from '../../types/darkpool';

const num = (v: number) => v.toLocaleString('en-US');
const signedPct = (v: number) => `${v > 0 ? '+' : v < 0 ? '−' : ''}${Math.abs(v).toFixed(2)}%`;
const INTENT_INK: Record<DarkPoolIntent, string> = { ACCUMULATION: 'text-bull', DISTRIBUTION: 'text-bear', 'HEDGE FLOW': 'text-warn', ROTATION: 'text-textMuted' };
const INTENT_BAR: Record<DarkPoolIntent, string> = { ACCUMULATION: 'bg-bull/80', DISTRIBUTION: 'bg-bear/80', 'HEDGE FLOW': 'bg-warn/80', ROTATION: 'bg-ink/25' };
/** The read's ink as a token name, for the canvas */
const INTENT_TOKEN: Record<DarkPoolIntent, string> = { ACCUMULATION: '--bull', DISTRIBUTION: '--bear', 'HEDGE FLOW': '--warn', ROTATION: '--text-muted' };
const ROLE_INK: Record<LevelRole, string> = { SUPPORT: 'text-bull', RESISTANCE: 'text-bear', PIVOT: 'text-textMuted' };
const ROLE_TOKEN: Record<LevelRole, string> = { SUPPORT: '--bull', RESISTANCE: '--bear', PIVOT: '--text-muted' };
const ROLE_WORD: Record<LevelRole, string> = { SUPPORT: 'support', RESISTANCE: 'resistance', PIVOT: 'pivot' };

const IntentTag = ({ intent }: { intent: DarkPoolIntent }) => (
  <span className={`font-mono text-[10px] font-semibold uppercase tracking-wider whitespace-nowrap ${INTENT_INK[intent]}`}>{intent}</span>
);

/** The shelf a cross landed on, if any — the nearest within a tenth of a percent */
const shelfOf = (p: DarkPoolPrint, view: DarkPoolView | null) => {
  if (!view || !p.atLevel) return null;
  let best = null as DarkPoolView['levels'][number] | null;
  for (const l of view.levels) if (Math.abs(l.price - p.price) / p.price < 0.0015 && (!best || Math.abs(l.price - p.price) < Math.abs(best.price - p.price))) best = l;
  return best;
};

/* THE TAPE: the stock's day as a line, the name's crosses as bars at their minute in their read's ink, the shelves as
   dashed price lines — the library, never a hand-drawn chart */
const CrossTape = ({ print, view }: { print: DarkPoolPrint; view: DarkPoolView | null }) => {
  const hostRef = useRef<HTMLDivElement | null>(null);
  const paper = useResolvedTheme() === 'light';
  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    const candles = Simulator.getCandles(print.ticker) ?? [];
    const day = candles.slice(-390);
    if (day.length === 0) return;
    const s = daySurface(host, paper);
    const chart: IChartApi = createChart(host, { ...dayChartOptions(s, { clock: false, logo: false }), autoSize: true });
    const price = chart.addSeries(LineSeries, {
      color: readToken('--text-primary', 0.85, host),
      lineWidth: 1,
      priceLineVisible: false,
      lastValueVisible: true,
      crosshairMarkerVisible: false,
    });
    price.setData(day.map(c => ({ time: c.time as UTCTimestamp, value: c.close })));
    const bars = chart.addSeries(HistogramSeries, { priceScaleId: 'dark', priceFormat: { type: 'volume' }, priceLineVisible: false, lastValueVisible: false });
    chart.priceScale('dark').applyOptions({ scaleMargins: { top: 0.72, bottom: 0 }, visible: false });
    /* a cross's minute → the candle at that clock */
    const atClock = new Map<string, number>();
    for (const c of day) atClock.set(nyClock(c.time * 1000), c.time);
    const crosses = (view?.prints ?? [print])
      .map(p => ({ p, t: atClock.get(p.time) }))
      .filter((x): x is { p: DarkPoolPrint; t: number } => x.t != null)
      .sort((a, b) => a.t - b.t);
    const seen = new Set<number>();
    bars.setData(
      crosses
        .filter(x => (seen.has(x.t) ? false : (seen.add(x.t), true)))
        .map(x => ({ time: x.t as UTCTimestamp, value: x.p.notional, color: readToken(INTENT_TOKEN[x.p.intent], x.p.id === print.id ? 1 : 0.55, host) }))
    );
    for (const l of view?.levels ?? [])
      price.createPriceLine({ price: l.price, color: readToken(ROLE_TOKEN[l.role], 0.7, host), lineWidth: 1, lineStyle: LineStyle.Dashed, axisLabelVisible: true, title: ROLE_WORD[l.role] });
    /* this cross, marked on the price line */
    const at = atClock.get(print.time);
    if (at != null) price.createPriceLine({ price: print.price, color: readToken('--silver', 0.9, host), lineWidth: 1, lineStyle: LineStyle.Dotted, axisLabelVisible: true, title: 'this cross' });
    chart.timeScale().fitContent();
    return () => chart.remove();
  }, [print, view, paper]);
  return <div ref={hostRef} className="h-[240px] w-full" data-cross-tape={print.ticker} />;
};

interface CrossDrilldownProps {
  print: DarkPoolPrint | null;
  /** The name's dark view today — its shelves and its other crosses; null while it is being read */
  view: DarkPoolView | null;
  onClose: () => void;
  onStep?: (dir: -1 | 1) => void;
  hasPrev?: boolean;
  hasNext?: boolean;
  /** Another cross of the sequence pressed */
  onOpen?: (p: DarkPoolPrint) => void;
}

const CrossDrilldown = ({ print, view, onClose, onStep, hasPrev = false, hasNext = false, onOpen }: CrossDrilldownProps) => {
  const navigate = useNavigate();
  const { isWatched, toggle } = useWatch();
  const key = print ? crossKey(print) : '';
  const marked = !!print && isWatched(key);
  const shelf = useMemo(() => (print ? shelfOf(print, view) : null), [print, view]);
  const sequence = useMemo(() => (view ? [...view.prints].sort((a, b) => (a.time === b.time ? b.notional - a.notional : a.time < b.time ? 1 : -1)) : []), [view]);
  const grade = print ? gradeOfConviction(print.conviction) : 'poor';
  return (
    <Modal
      open={!!print}
      onClose={onClose}
      widthClass="max-w-[1180px]"
      ariaLabel={print ? `${print.ticker} dark pool cross at ${print.time}` : 'dark pool cross'}
      header={
        print && (
          <span className="flex items-center gap-2.5 min-w-0">
            <CompanyLogo ticker={print.ticker} size={16} />
            <span className="font-mono text-[12px] font-bold text-textPrimary">{print.ticker}</span>
            <span className="text-[11px] text-textMuted">cross</span>
            <span className="font-mono text-[11px] tnum text-textSecondary">{print.time}</span>
            <IntentTag intent={print.intent} />
          </span>
        )
      }
      headerCenter={
        onStep && (
          <div className="group relative flex items-center gap-0.5 rounded holo-bg text-[#0a0a0a] px-1 py-0.5" data-cross-steps>
            <button onClick={() => onStep(-1)} disabled={!hasPrev} title="The newer cross" className="p-0.5 rounded disabled:opacity-30 transition-colors" data-cross-prev>
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <span className="px-1.5 font-mono text-[11px] font-semibold tnum">{print?.time}</span>
            <button onClick={() => onStep(1)} disabled={!hasNext} title="The older cross" className="p-0.5 rounded disabled:opacity-30 transition-colors" data-cross-next>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )
      }
      headerActions={
        print && (
          <div className="flex items-center gap-0.5 shrink-0">
            <button
              onClick={() => toggle(watchedCross(print, view?.spot ?? print.price, 'dark-pool'))}
              aria-pressed={marked}
              title={marked ? 'Let go of this cross — it leaves the Tracker' : 'Keep this cross — it goes on the Tracker'}
              className={`p-1.5 rounded transition-colors ${marked ? 'text-silver' : 'text-textMuted hover:text-textPrimary hover:bg-ink/[0.06]'}`}
              data-cross-mark={marked || undefined}
            >
              <Bookmark className="w-4 h-4" fill={marked ? 'currentColor' : 'none'} />
            </button>
            <button
              onClick={() => navigate('/terrain', { state: { chart: { ticker: print.ticker, focus: shelf?.price ?? print.price }, wayBack: '/trace/dark-pool' } })}
              title="See it on the chart — Terrain at the shelf"
              className="p-1.5 rounded text-textMuted hover:text-textPrimary hover:bg-ink/[0.06] transition-colors"
              data-cross-chart
            >
              <Crosshair className="w-4 h-4" />
            </button>
            <button
              onClick={() => navigate('/weigher', { state: { ticker: print.ticker } })}
              title="Weigh the name"
              className="p-1.5 rounded text-textMuted hover:text-textPrimary hover:bg-ink/[0.06] transition-colors"
              data-cross-weigh
            >
              <Scale className="w-4 h-4" />
            </button>
          </div>
        )
      }
    >
      {print && (
        <div className="flex flex-col" data-cross-card={key}>
          {/* THE BAND: the dollars lead, then what printed where */}
          <div className="px-5 pt-4 pb-3 flex items-baseline gap-3 flex-wrap">
            <span className="font-mono text-[22px] font-bold tnum text-textPrimary">{fmtUsd(print.notional)}</span>
            <span className="font-mono text-[12px] tnum text-textSecondary">
              {num(print.size)} shares <span className="text-textMuted">@</span> ${print.price.toFixed(2)} <span className="text-textMuted">on</span> {print.venue}
            </span>
            <span className={`font-mono text-[11px] tnum ${print.vsSpotPct > 0 ? 'text-bull' : print.vsSpotPct < 0 ? 'text-bear' : 'text-textMuted'}`}>{signedPct(print.vsSpotPct)} vs spot</span>
            {print.sized && <span className="font-mono text-[9px] font-semibold uppercase tracking-widest rounded px-1.5 py-0.5 bg-silverFill text-[#0a0a0a]">sized</span>}
          </div>
          <p className="px-5 pb-4 text-[12px] leading-relaxed text-textSecondary border-b border-borderSubtle" data-cross-read>
            {print.read}
          </p>

          {/* THE FACTS, two columns of dot-leader rows */}
          <div className="px-5 py-3 grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-1 border-b border-borderSubtle" data-cross-facts>
            <Fact
              label="Conviction"
              value={
                <span className="inline-flex items-center gap-2">
                  <span className={INTENT_INK[print.intent]}>{grade}</span>
                  <GradeMeter grade={grade} fill={INTENT_BAR[print.intent]} thin className="w-16" />
                </span>
              }
            />
            <Fact label="Shelf" value={shelf ? <span className={ROLE_INK[shelf.role]}>${shelf.price.toFixed(2)} · {ROLE_WORD[shelf.role]} · defended {shelf.defended}×</span> : <span className="text-textMuted">between shelves</span>} />
            <Fact
              label={`${print.ticker} today`}
              value={
                view ? (
                  <span className={view.posture === 'ACCUMULATING' ? 'text-bull' : view.posture === 'DISTRIBUTING' ? 'text-bear' : 'text-textSecondary'}>
                    {POSTURE_WORD[view.posture]}
                    {view.posture !== 'BALANCED' ? ` · ${gradeOfPosture(view.netPosturePct)}` : ''}
                  </span>
                ) : (
                  '—'
                )
              }
            />
            <Fact label="Off-exchange" value={view ? `${view.dpSharePct.toFixed(0)}% of volume` : '—'} />
            <Fact label="Dark dollars today" value={view ? fmtUsd(view.totalNotional) : '—'} />
            <Fact label="Crosses today" value={view ? `${view.prints.length} · ${view.prints.filter(p => p.sized).length} sized` : '—'} />
          </div>

          {/* THE SEQUENCE — the same name's crosses, newest first, this one lit */}
          <div className="px-5 pt-3 pb-1 flex items-baseline gap-3">
            <span className="font-mono text-[10px] font-semibold uppercase tracking-widest text-textPrimary">The sequence</span>
            <span className="text-[11px] text-textMuted">{print.ticker}'s crosses on the tape today</span>
          </div>
          <div className="px-5 pb-3 border-b border-borderSubtle max-h-[176px] overflow-y-auto" data-cross-sequence>
            {sequence.map(p => {
              const here = p.id === print.id;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => onOpen?.(p)}
                  aria-current={here || undefined}
                  className={`w-full text-left grid grid-cols-[52px_84px_96px_96px_minmax(0,1fr)] items-center gap-x-3 h-[30px] rounded px-2 font-mono text-[11px] tnum transition-colors ${
                    here ? 'bg-silver/[0.08] text-textPrimary' : 'text-textSecondary hover:bg-silver/[0.05]'
                  }`}
                  data-cross-seq={p.id}
                >
                  <span>{p.time}</span>
                  <span className="text-right">${p.price.toFixed(2)}</span>
                  <span className="text-right">{num(p.size)}</span>
                  <span className="text-right">{fmtUsd(p.notional)}</span>
                  <IntentTag intent={p.intent} />
                </button>
              );
            })}
          </div>

          {/* THE TAPE — the name's day with its crosses and its shelves */}
          <div className="px-5 pt-3 pb-1 flex items-baseline gap-3">
            <span className="font-mono text-[10px] font-semibold uppercase tracking-widest text-textPrimary">The tape</span>
            <span className="text-[11px] text-textMuted">the stock's day · the crosses as bars in their read's ink · the shelves dashed · this cross dotted</span>
          </div>
          <div className="px-3 pb-3">
            <CrossTape print={print} view={view} />
          </div>
        </div>
      )}
    </Modal>
  );
};

export default CrossDrilldown;
