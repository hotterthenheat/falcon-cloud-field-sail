import type { IChartApi, ISeriesApi, ISeriesPrimitive, SeriesAttachedParameter, Time, UTCTimestamp } from 'lightweight-charts';

/*
==================================================
  SLAYER TERMINAL - THE THERMAL FIELD
  (components/gex/thermalFieldPrimitive.ts)

  Where price is likelier to be between now and the
  close, painted on the tape as heat (Noah, 2026-10-14,
  with Skylit's cloud ahead of price: "i need this
  'cone' that should be estimating price movement
  throughout the day to look better, i dont think a
  cone will do it … something similar to that but
  more 'thermal' vibes to indicate where its hotter
  vs colder in that designated area"). The two dotted
  lines of the expected move are gone; in their place,
  from the last bar to the close, every minute is a
  column of colour: hottest at the centre the strikes
  have pulled the range to (the Ahead model's
  corridor, data/ahead.ts buildCorridor — the odds
  curve's centre of mass, the walls bending the band),
  warm out to one expected move, cool out to two, and
  nothing beyond. The thermal ramp's own inks: the
  warm red at the core, its yellow halfway out, the
  cool blue at the edge.

  A SERIES PRIMITIVE, the house's way (the expected
  move on the Terrain tape, the session levels): it
  draws on the chart's own canvas under the price
  line, placed by the chart's coordinates — the clock
  has a real point for every minute of the session
  (dayChart.ts dayClock), so a minute's x is the time
  scale's own answer.
==================================================
*/

/** One minute of the field: the band's edges and its hot centre, in price */
export interface FieldPoint {
  /** New York minutes from midnight */
  min: number;
  lo2: number;
  lo1: number;
  mid: number;
  hi1: number;
  hi2: number;
}

export type Rgb = [number, number, number];

export interface FieldData {
  /** The epoch second at New York's midnight of the session's day (dayChart.ts dayStartOf) */
  dayStart: number;
  points: FieldPoint[];
  /** The thermal ramp's inks, resolved off the page (paletteInk resolveInk) */
  warm: Rgb;
  yellow: Rgb;
  cool: Rgb;
  /** The core's strength — the page's ground shows through everywhere */
  strength: number;
}

interface BitmapScope {
  context: CanvasRenderingContext2D;
  horizontalPixelRatio: number;
  verticalPixelRatio: number;
  mediaSize: { width: number; height: number };
}
interface DrawTarget {
  useBitmapCoordinateSpace(cb: (scope: BitmapScope) => void): void;
}

const rgba = (c: Rgb, a: number) => `rgba(${c[0]},${c[1]},${c[2]},${a.toFixed(3)})`;

/** The thermal ramp's yellow halfway out (heatmap.ts 'thermal-yellow' at 0.2) — the one ink the tokens do not carry */
export const THERMAL_YELLOW: Rgb = [254, 224, 144];
/** A resolved ink's channels, for the canvas — "rgb(r, g, b)" or "r g b" */
export const rgbOf = (s: string): Rgb => {
  const m = s.match(/\d+(?:\.\d+)?/g) ?? [];
  return [Number(m[0]) || 0, Number(m[1]) || 0, Number(m[2]) || 0];
};
/** The field's inks and its core's strength — what a host hands any primitive that paints the field */
export interface ThermalInks {
  warm: Rgb;
  yellow: Rgb;
  cool: Rgb;
  strength: number;
}

/**
 * ONE COLUMN OF THE FIELD (shared since 2026-10-15 — Terrain's expected move paints it too): the column xa..xb in
 * device px with a vertical gradient between its five prices as device y — cool and clear at two moves out, cool at
 * one, yellow halfway in, the warm core at the centre; the stops must climb, so a flat band is skipped.
 */
export function paintThermalColumn(ctx: CanvasRenderingContext2D, xa: number, xb: number, yHi2: number, yHi1: number, yMid: number, yLo1: number, yLo2: number, inks: ThermalInks, hDev: number): void {
  if (xb <= xa) return;
  const span = yLo2 - yHi2;
  if (!(span > 0.5)) return;
  const { warm, yellow, cool, strength } = inks;
  const at = (y: number) => Math.max(0, Math.min(1, (y - yHi2) / span));
  const yHiHalf = yMid - (yMid - yHi1) / 2;
  const yLoHalf = yMid + (yLo1 - yMid) / 2;
  const g = ctx.createLinearGradient(0, yHi2, 0, yLo2);
  const stops: [number, string][] = [
    [0, rgba(cool, 0)],
    [at(yHi1), rgba(cool, strength * 0.45)],
    [at(yHiHalf), rgba(yellow, strength * 0.7)],
    [at(yMid), rgba(warm, strength)],
    [at(yLoHalf), rgba(yellow, strength * 0.7)],
    [at(yLo1), rgba(cool, strength * 0.45)],
    [1, rgba(cool, 0)],
  ];
  let last = -1;
  for (const [pos, col] of stops) {
    const q = Math.max(last + 1e-4, Math.min(1, pos));
    if (q > 1) break;
    g.addColorStop(q, col);
    last = q;
  }
  ctx.fillStyle = g;
  const top = Math.max(0, yHi2);
  const bottom = Math.min(hDev, yLo2);
  if (bottom > top) ctx.fillRect(xa, top, xb - xa, bottom - top);
}

class ThermalFieldRenderer {
  constructor(private source: ThermalFieldPrimitive) {}

  draw(target: DrawTarget): void {
    const src = this.source;
    const chart = src.chart;
    const series = src.series;
    const data = src.data;
    if (!chart || !series || !data || data.points.length < 2) return;
    target.useBitmapCoordinateSpace(scope => {
      const ctx = scope.context;
      const hr = scope.horizontalPixelRatio;
      const vr = scope.verticalPixelRatio;
      const w = scope.mediaSize.width * hr;
      const h = scope.mediaSize.height * vr;
      const ts = chart.timeScale();
      const xOf = (min: number): number | null => {
        const x = ts.timeToCoordinate((data.dayStart + min * 60) as UTCTimestamp);
        return x === null ? null : x * hr;
      };
      const yOf = (price: number): number | null => {
        const y = series.priceToCoordinate(price);
        return y === null ? null : y * vr;
      };
      ctx.save();
      /* one column a minute, its own vertical gradient: cool and clear at two moves out, cool at one, yellow halfway in,
         the warm core at the centre — the next minute's column starts where this one ends, so the field is one surface */
      for (let i = 0; i < data.points.length; i++) {
        const p = data.points[i];
        const x0 = xOf(p.min);
        const x1 = i + 1 < data.points.length ? xOf(data.points[i + 1].min) : null;
        if (x0 === null) continue;
        /* TILED TO WHOLE DEVICE PIXELS: columns that overlapped by half a pixel painted their alpha twice at every seam,
           and the field read as ribbed */
        const xa = Math.round(x0);
        const xb = Math.round(x1 === null ? x0 + Math.max(1, hr) : x1);
        if (xb <= xa || xb < 0 || xa > w) continue;
        const yHi2 = yOf(p.hi2);
        const yLo2 = yOf(p.lo2);
        const yHi1 = yOf(p.hi1);
        const yLo1 = yOf(p.lo1);
        const yMid = yOf(p.mid);
        if (yHi2 === null || yLo2 === null || yHi1 === null || yLo1 === null || yMid === null) continue;
        paintThermalColumn(ctx, xa, xb, yHi2, yHi1, yMid, yLo1, yLo2, data, h);
      }
      ctx.restore();
    });
  }
}

class ThermalFieldPaneView {
  private _renderer: ThermalFieldRenderer;
  constructor(source: ThermalFieldPrimitive) {
    this._renderer = new ThermalFieldRenderer(source);
  }
  /* under the price line and its levels — the field is the ground the day's path runs on */
  zOrder(): 'bottom' {
    return 'bottom';
  }
  renderer(): ThermalFieldRenderer {
    return this._renderer;
  }
}

export class ThermalFieldPrimitive implements ISeriesPrimitive<Time> {
  chart: IChartApi | null = null;
  series: ISeriesApi<'Area'> | null = null;
  requestUpdate?: () => void;
  data: FieldData | null = null;
  private _paneViews: ThermalFieldPaneView[];

  constructor() {
    this._paneViews = [new ThermalFieldPaneView(this)];
  }

  attached(param: SeriesAttachedParameter<Time>): void {
    this.chart = param.chart;
    this.series = param.series as ISeriesApi<'Area'>;
    this.requestUpdate = param.requestUpdate;
  }

  detached(): void {
    this.chart = null;
    this.series = null;
    this.requestUpdate = undefined;
  }

  updateAllViews(): void {}

  paneViews(): ThermalFieldPaneView[] {
    return this._paneViews;
  }

  setData(next: FieldData | null): void {
    const wasOff = this.data === null;
    this.data = next;
    if (!(wasOff && next === null)) this.requestUpdate?.();
  }
}
