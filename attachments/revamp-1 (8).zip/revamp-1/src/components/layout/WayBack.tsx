/*
==================================================
  SLAYER TERMINAL - THE WAY BACK (components/layout/WayBack.tsx)

  A page opened FROM somewhere else carries a way
  back to it (Noah, 2026-09-12, on the Pulse desk:
  "it should take user to the actual page with a
  button allowing them to go back to the pulse page
  from there"). The opener navigates with
  `state: { wayBack: '/pulse' }`; this pill reads
  it on whatever page it landed on and takes the
  reader back on a click. It rides the route's
  state, so a step deeper into the section (no
  state) drops it and the browser's Back brings it
  with the page. Mounted once, in the shell.
==================================================
*/

import { useEffect, useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';

/** How the origin is named on the pill */
const NAMES: Record<string, string> = {
  '/pulse': 'Pulse',
  '/pinpoint': 'the Map',
  '/pinpoint/map': 'the Map',
  '/pinpoint/board': 'the Board',
  '/pinpoint/agenda': 'the Agenda',
  '/pinpoint/compare': 'Compare',
};
/* A name's page on the Record is named by the name (the busiest rows' way
   back, 2026-09-12); any other origin is plainly "back" */
const nameFor = (to: string): string => {
  if (NAMES[to]) return NAMES[to];
  /* a name's page under the Record — the earnings page or the stock overview (2026-09-13) */
  const m = to.match(/^\/(?:dossier|record)\/(?:earnings|stocks)\/([^/?#]+)/);
  if (m) return decodeURIComponent(m[1]).toUpperCase();
  return '';
};

export type WayBackState = { wayBack?: string };

/* The pill floats at the TOP CENTRE of the content column — the one strip every
   shell head leaves empty (the name at its left, the facts at its right); the
   corners are not (the Map's foot, the door home). The column starts after the
   sidebar, whose width glides, so the centre is measured off <main>. */
const useMainCentre = () => {
  const [left, setLeft] = useState<{ centre: number; edge: number } | null>(null);
  useEffect(() => {
    const main = document.querySelector<HTMLElement>('main');
    if (!main) return;
    const read = () => {
      const r = main.getBoundingClientRect();
      setLeft({ centre: r.left + r.width / 2, edge: r.left });
    };
    read();
    const ro = new ResizeObserver(read);
    ro.observe(main);
    window.addEventListener('resize', read);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', read);
    };
  }, []);
  return left;
};

const WayBack = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const to = (location.state as WayBackState | null)?.wayBack;
  const at = useMainCentre();
  if (!to || at == null) return null;
  const name = nameFor(to);
  /* TERRAIN HAS NO HEAD (2026-09-30: Pulse's chart tile and the Focus chip's Chart door both land there): its panes run
     to the top edge, and the top centre is the second pane's own name. Its one empty corner is the foot's left. */
  const low = location.pathname.startsWith('/terrain');
  return (
    <button
      onClick={() => navigate(to)}
      title={name ? `Back to ${name}` : 'Back'}
      data-way-back={to}
      style={{ left: low ? at.edge + 12 : at.centre }}
      data-way-back-at={low ? 'foot' : 'head'}
      className={`group fixed ${low ? 'bottom-2.5' : 'top-[60px] md:top-3 -translate-x-1/2'} z-[70] inline-flex items-center gap-1.5 h-8 pl-2.5 pr-3 rounded-full border border-borderMuted bg-panel/90 backdrop-blur-sm font-mono text-[11px] font-semibold text-textSecondary hover:text-textPrimary hover:bg-panelHover shadow-lg shadow-black/40 transition-colors animate-soft-in`}
    >
      <ArrowLeft className="w-3.5 h-3.5 transition-transform duration-200 ease-out group-hover:-translate-x-0.5" />
      {name ? `Back to ${name}` : 'Back'}
    </button>
  );
};

export default WayBack;
