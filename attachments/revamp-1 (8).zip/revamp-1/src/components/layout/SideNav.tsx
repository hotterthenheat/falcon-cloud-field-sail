/*
==================================================
  SLAYER TERMINAL - THE SIDEBAR (components/layout/SideNav.tsx)

  The frame, direction B (Noah, 2026-09-05): the
  terminal's ONE SUBJECT sits first, before
  navigation; under it the groups and their pages,
  with the current product's pages nested; at the
  bottom the one honest line about the data and
  the clock.

  THE LOOK (Noah, 2026-09-06, the second reference —
  Tomasz Trefler's "Left Side Menu"): the sidebar
  HUGS THE SIDE — no inset, no floating card, a
  full-height panel with one hairline on its right.
  The mark and the wordmark on top, the subject
  dressed as the search field, one utility row
  (Alerts, with its count), then small uppercase
  section labels, tight icon + label rows, and the
  current product's pages on a TREE RAIL — a
  vertical line whose bright part fills down to the
  page you are on, "the completion bar feel". The
  current product is a soft pill with a silver bar
  on the panel's edge; a round notch on that edge
  collapses it to a 52px icon rail that keeps our
  ">_" mark (Noah: "i do love this logo though for
  the collapsed look").

  Why the edge bar is ONE element on the panel and
  not a pseudo-element on each row: the rows live
  inside a scroller that clips sideways, and a bar
  hung off a row would be cut at the padding. One
  bar, measured against the current row, glides
  between pages instead of blinking.
==================================================
*/

import { useCallback, useEffect, useLayoutEffect, useRef, useState, type CSSProperties, type MouseEvent } from 'react';
import { createPortal } from 'react-dom';
import { NavLink, useLocation } from 'react-router-dom';
import { ChevronDown, ChevronLeft, ChevronRight, Eye, Lock, Menu, Search, UserRound } from 'lucide-react';
import { useAccess } from '../../data/access';
import JingleBell from '../ui/JingleBell';
import Fold from '../ui/Fold';
import Avatar from '../ui/Avatar';
import { useProfile } from '../../data/profile';
import { useAccount } from '../../data/account';
import { useMarketData } from '../../context/MarketDataContext';
import { useLaunch } from './LaunchTransition';
import CompanyLogo from '../ui/CompanyLogo';
import { NAV_GROUPS, NAV_GROUP_META, NAV_INK, itemsByGroup } from './nav';
import { subpagesFor } from './navTree';
import MobileMenu from './MobileMenu';
import { useCompassView } from '../../data/compassView';
import { lookup } from '../../data/universe';
import { readSessionClock } from '../../data/moc';
import { useAllAlerts, useUnseenAll } from '../gex/alertStore';
import { toggleAlertsDrawer, useAlertsDrawer } from '../../data/alertsDrawer';
import { toggleWatchlist, useNameWatch, useWatchlistOpen } from '../../data/nameWatch';
import { beginGlide, endGlide } from '../../core/glide';
import { alpha } from '../gex/paletteInk';
import { EMBEDDED } from '../../embed';
import SlayerMark from '../../brand/SlayerMark';
import PageGlyph from '../ui/PageGlyph';
import Wordmark from '../../brand/Wordmark';
import Signature, { SignatureDot } from '../../brand/Signature';
import { readMarketState } from '../../data/marketState';

const SILVER = 'rgb(var(--silver))'; /* the silver token — deep steel on the light terminal (2026-09-12) */
const COLLAPSED_KEY = 'slayer_sidenav_collapsed';
/** The panel's widths — open, and the icon rail */
export const SIDENAV_W = 236;
export const SIDENAV_RAIL_W = 52;
/** The edge bar's height */
const BAR_H = 18;
/** A nested page row's pitch — the tree fill is computed from it, not measured */
const SUB_H = 26;

/* which pages sit under each product is navTree.ts — the phone's menu reads the same list */

const readCollapsed = () => {
  /* in the landing's window the rail opens folded, so the page has the width — and unwritten (embed.ts) */
  if (EMBEDDED) return true;
  try {
    return localStorage.getItem(COLLAPSED_KEY) === '1';
  } catch {
    return false;
  }
};

interface SideNavProps {
  onOpenPalette: () => void;
}

interface Tip {
  label: string;
  x: number;
  y: number;
}

const SideNav = ({ onOpenPalette }: SideNavProps) => {
  const { activeTicker, marketData } = useMarketData();
  /* the contract the reader is inside — Compass's tree keeps its row (see subpagesFor) */
  const { chosenId } = useCompassView();
  const profile = useProfile();
  /* the foot is a sign-in door while no one is signed in (2026-10-03, the account service); without the service the
     sample profile stands as before */
  const account = useAccount();
  const signedOut = account.status === 'out' || account.status === 'loading';
  const { launch } = useLaunch();
  const { pathname } = useLocation();
  const [collapsed, setCollapsed] = useState(readCollapsed);
  const [menuOpen, setMenuOpen] = useState(false);
  const closeMenu = useCallback(() => setMenuOpen(false), []);
  const [clock, setClock] = useState(() => readSessionClock());
  const [time, setTime] = useState(() => new Date().toLocaleTimeString('en-US', { hour12: false }));
  const asideRef = useRef<HTMLElement | null>(null);
  const navRef = useRef<HTMLElement | null>(null);
  const [bar, setBar] = useState<{ top: number } | null>(null);
  const [tip, setTip] = useState<Tip | null>(null);
  /* EVERY name's alerts (the rule, 2026-09-10: the bell counts across all
     names, not the subject's alone) — how many are set, how many fired
     unseen, and whether the drawer is open */
  const allAlerts = useAllAlerts();
  const setTotal = allAlerts.reduce((n, a) => n + a.alerts.filter(x => !x.firedAt).length, 0);
  const unseen = useUnseenAll();
  const drawerOpen = useAlertsDrawer();

  useEffect(() => {
    const id = window.setInterval(() => {
      setClock(readSessionClock());
      setTime(new Date().toLocaleTimeString('en-US', { hour12: false }));
    }, 1000);
    return () => window.clearInterval(id);
  }, []);

  const toggleCollapsed = () => {
    /* The main column is told where it is going (core/glide.ts): its width
       once this panel has folded or opened — the desk lays its tiles out for
       that at once and rides the glide there; the charts that cannot afford a
       resize per frame size for it at the start. Measured off <main>, not the
       viewport, so a scrollbar or a drawer changes nothing. */
    const main = document.querySelector('main');
    const next = collapsed ? SIDENAV_W : SIDENAV_RAIL_W;
    const to = main ? { mainWidth: main.getBoundingClientRect().width + (width - next) } : null;
    beginGlide(700, 'frame', to);
    setCollapsed(c => {
      if (!EMBEDDED) {
        try {
          localStorage.setItem(COLLAPSED_KEY, c ? '0' : '1');
        } catch {
          /* private mode — the choice lives for the session */
        }
      }
      return !c;
    });
    setTip(null);
  };

  /* THE EDGE BAR follows the current product row: measured against the
     panel, so it rides the edge whatever the scroller is doing; hidden while
     the row is scrolled out of the nav's window. */
  const measure = useCallback(() => {
    const aside = asideRef.current;
    const nav = navRef.current;
    const row = aside?.querySelector<HTMLElement>('[data-nav-current]');
    if (!aside || !nav || !row) {
      setBar(null);
      return;
    }
    const a = aside.getBoundingClientRect();
    const n = nav.getBoundingClientRect();
    const r = row.getBoundingClientRect();
    const mid = r.top + r.height / 2;
    if (mid < n.top || mid > n.bottom) {
      setBar(null);
      return;
    }
    setBar({ top: Math.round(mid - a.top - BAR_H / 2) });
  }, []);
  /* A frame after the commit, never inside it (2026-09-06, the perf sweep):
     measured in a layout effect on every route change, the three rects
     forced the NEW page's whole layout early — 24ms of every page's open
     on the profiler, charged to the sidebar. The bar glides on a 300ms
     transition anyway; one frame is nothing to it. */
  useEffect(() => {
    const id = requestAnimationFrame(measure);
    return () => cancelAnimationFrame(id);
  }, [measure, pathname, collapsed]);
  useEffect(() => {
    const nav = navRef.current;
    nav?.addEventListener('scroll', measure, { passive: true });
    window.addEventListener('resize', measure);
    return () => {
      nav?.removeEventListener('scroll', measure);
      window.removeEventListener('resize', measure);
    };
  }, [measure]);

  /* A hover tip for the rail — one fixed label beside the row, never clipped */
  const showTip = (e: MouseEvent<HTMLElement>, label: string) => {
    if (!collapsed) return;
    const r = e.currentTarget.getBoundingClientRect();
    setTip({ label, x: r.right + 10, y: r.top + r.height / 2 });
  };
  const hideTip = () => setTip(null);

  const name = lookup(activeTicker)?.name ?? null;
  const change = marketData?.changePercent ?? 0;
  const open = clock.phase === 'OPEN' || clock.phase === 'AUCTION';
  const priceText = marketData ? `$${marketData.spot.toFixed(2)}` : '—';
  const changeText = marketData ? `${change >= 0 ? '+' : ''}${change.toFixed(2)}%` : '';

  /* the signature's word, read on the clock's own tick so the dot and the session line never disagree */
  const marketWord = readMarketState().word;

  /* THE MARK AND THE WORDMARK — the door home. HIS PARTNER'S LOGO SYSTEM (Noah, 2026-10-03, shown his marks beside
     ours: "all of it"): the bare S|, the foil panning across it and the cursor blinking on the page's beat, and
     ">slayer_terminal" drawn as outlines beside it; folded, the S| alone — with its cursor held lit (index.css: a lone S
     beside the rail's notch read as cut whenever the cursor blinked off; Noah, 2026-10-03). The S brightens as the pointer
     nears it. (The S on the holo tile and the word that typed itself on, 2026-09-30, went with the switch.) */
  const brand = (
    <a
      href="/"
      onClick={e => {
        e.preventDefault();
        launch('/');
      }}
      onMouseEnter={e => showTip(e, 'Home')}
      onMouseLeave={hideTip}
      /* ONE LEFT INSET, open or shut (the anchor rule): 14 centres the 24px mark in the 52px rail, and the row clips to
         the panel's own width; the word fades rather than cuts while the panel glides */
      className="shrink-0 w-full overflow-hidden flex items-center gap-2.5 h-[52px] select-none pl-[14px] pr-0"
      aria-label="Slayer Terminal — the front page"
      data-brand
    >
      <SlayerMark size={24} bare near label="" />
      <span className={`inline-flex transition-opacity duration-200 ${collapsed ? 'opacity-0' : 'opacity-100'}`} aria-hidden={collapsed || undefined} data-brand-word>
        <Wordmark height={12} label="" className="translate-y-[1px]" />
      </span>
    </a>
  );

  /* THE SUBJECT, dressed as the search field under the mark: the name you
     are on, its price and change, and the key that changes it. */
  const subject = collapsed ? (
    <button
      type="button"
      onClick={onOpenPalette}
      data-subject
      aria-label={`Watching ${activeTicker} ${priceText} — switch`}
      onMouseEnter={e => showTip(e, `${activeTicker} ${priceText} ${changeText} · ⌘K to switch`)}
      onMouseLeave={hideTip}
      className="ml-[10px] w-8 h-8 rounded-lg border border-ink/[0.08] bg-ink/[0.03] hover:border-silver/50 transition-colors flex items-center justify-center"
    >
      <CompanyLogo ticker={activeTicker} size={16} />
    </button>
  ) : (
    <button
      type="button"
      onClick={onOpenPalette}
      data-subject
      aria-label={`Watching ${activeTicker} — switch`}
      title={name ? `${name} · ⌘K to switch` : '⌘K to switch'}
      className="group w-full h-[34px] rounded-lg border border-ink/[0.08] bg-ink/[0.03] hover:border-silver/50 hover:bg-ink/[0.05] transition-colors flex items-center gap-2 pl-2 pr-2 text-left"
    >
      <CompanyLogo ticker={activeTicker} size={16} />
      <span className="text-[12px] font-semibold text-textPrimary" data-subject-ticker>
        {activeTicker}
      </span>
      <span className="font-mono text-[11px] tnum text-textPrimary" data-subject-price>
        {priceText}
      </span>
      {marketData && <span className={`font-mono text-[10px] tnum ${change >= 0 ? 'text-bull' : 'text-bear'}`}>{changeText}</span>}
      <span className="ml-auto inline-flex items-center gap-1 text-textMuted group-hover:text-textSecondary transition-colors">
        <Search className="w-3 h-3" />
        <kbd className="font-mono text-[9px] tracking-wide">⌘K</kbd>
      </span>
    </button>
  );

  /* THE UTILITY ROW — every alert, with the count: fired-and-unseen in lime
     (live), else how many are set. It used to be a link to the Targets page
     ("where the bell lives"); now it opens THE DRAWER at the right, over
     whatever page the reader is on (Noah, 2026-09-10: "why is the alerts
     page just the targets page?"). Silver while the drawer is open. */
  const alertsRow = (
    <button
      type="button"
      onClick={toggleAlertsDrawer}
      data-nav-alerts
      aria-expanded={drawerOpen}
      onMouseEnter={e => showTip(e, unseen > 0 ? `${unseen} alerted` : setTotal > 0 ? `${setTotal} alert${setTotal === 1 ? '' : 's'} set` : 'Alerts')}
      onMouseLeave={hideTip}
      /* A BUTTON, so it must be told to fill its row (an anchor with
         `flex` stretches on its own; a button hugs its content — Noah,
         2026-09-10: "the alerts button doesnt look like the rest"). Open
         wears the nav rows' own current-desk look: the pill, primary
         medium text, the bell in its ink. */
      className={`group relative flex items-center gap-2.5 h-[30px] rounded-lg text-[13px] text-left transition-colors ${
        collapsed ? 'w-8 ml-[10px] justify-center' : 'w-full px-2.5'
      } ${drawerOpen ? 'bg-ink/[0.06] text-textPrimary font-medium' : 'text-textSecondary hover:text-textPrimary hover:bg-ink/[0.04]'}`}
      aria-label="Alerts"
    >
      {/* jingles when an alert is set on any name (Noah, 2026-09-10) — drawn as the Alerts glyph since the rail wears the
          landing's icons (2026-10-03); its dot is the alert ink always */}
      <JingleBell
        count={setTotal}
        ink={NAV_INK.alerts}
        lit={drawerOpen || unseen > 0}
        glyph={17}
        className={`shrink-0 transition-opacity duration-200 ${drawerOpen ? 'opacity-100' : 'opacity-80 group-hover:opacity-100'}`}
      />
      {!collapsed && <span>Alerts</span>}
      {/* WHAT ALERTED AND WAS NOT LOOKED AT: the number in a small RED curved
          square (Noah, 2026-09-10: "i dont like the alert color lime … a
          little red [badge] with a number in it" → "add the curved square
          instead") — on the icon's corner when the rail is collapsed, at the
          row's end when open. */}
      {collapsed
        ? unseen > 0 && (
            <span className="absolute -top-0.5 -right-0.5 min-w-[14px] h-[14px] px-[3px] rounded-[4px] bg-bear text-white font-mono text-[8px] font-bold leading-[14px] text-center tnum" data-alerts-count>
              {unseen > 9 ? '9+' : unseen}
            </span>
          )
        : unseen > 0 ? (
            <span className="ml-auto min-w-[18px] h-[18px] px-1 rounded-md bg-bear text-white font-mono text-[10px] font-bold leading-[18px] text-center tnum" data-alerts-count>
              {unseen > 99 ? '99+' : unseen}
            </span>
          ) : setTotal > 0 ? (
            <span className="ml-auto font-mono text-[10px] tnum text-textMuted" data-alerts-count>
              {setTotal} set
            </span>
          ) : null}
    </button>
  );

  /* THE WATCHLIST DOOR (2026-10-13, the partner's, at Noah's word): the one list of names
     (components/layout/WatchlistDrawer.tsx), opened at the right like the alerts — a small row
     under the bell, the count of names at its end */
  const watchOpen = useWatchlistOpen();
  const watchCount = useNameWatch().sections.reduce((n, s) => n + s.names.length, 0);
  const watchLabel = watchCount > 0 ? `Watchlist — ${watchCount} ${watchCount === 1 ? 'name' : 'names'}` : 'Watchlist';
  const watchRow = (
    <button
      type="button"
      onClick={toggleWatchlist}
      data-nav-watchlist
      aria-expanded={watchOpen}
      onMouseEnter={e => showTip(e, watchLabel)}
      onMouseLeave={hideTip}
      className={`group relative flex items-center gap-2.5 h-[30px] rounded-lg text-[13px] text-left transition-colors ${
        collapsed ? 'w-8 ml-[10px] justify-center' : 'w-full px-2.5'
      } ${watchOpen ? 'bg-ink/[0.06] text-textPrimary font-medium' : 'text-textSecondary hover:text-textPrimary hover:bg-ink/[0.04]'}`}
      aria-label={watchLabel}
    >
      <Eye className={`w-[17px] h-[17px] shrink-0 transition-opacity duration-200 ${watchOpen ? 'opacity-100' : 'opacity-80 group-hover:opacity-100'}`} strokeWidth={1.75} aria-hidden />
      {!collapsed && <span>Watchlist</span>}
      {!collapsed && watchCount > 0 && (
        <span className="ml-auto font-mono text-[10px] tnum text-textMuted" data-watchlist-count>
          {watchCount}
        </span>
      )}
    </button>
  );

  /* THE TREE FOLDS (Noah, 2026-09-28: "clicking it once gives a dropdown but when you click it again it should bring it
     back up"): a section's pages drop down when you enter it; a click on the section's row while you are inside folds
     them, another unfolds them — no navigation on those clicks. A section you leave forgets the fold, so coming back
     opens it again. */
  const [folded, setFolded] = useState<Record<string, boolean>>({});
  /* the plan held, for the locks on the rooms outside it (data/access.ts) */
  const access = useAccess();
  useEffect(() => {
    setFolded(f => {
      const next = Object.fromEntries(Object.entries(f).filter(([path]) => pathname.startsWith(path)));
      return Object.keys(next).length === Object.keys(f).length ? f : next;
    });
  }, [pathname]);

  /* THE RAIL'S ORDER (2026-09-28, nav.ts): Home (Pulse) stands ABOVE the Alerts row with no caption; the captioned
     groups scroll under; More (Community · Settings) is pinned to the foot of the list with no caption */
  const groupBlocks = NAV_GROUPS.map((group, gi) => {
    const meta = NAV_GROUP_META[group];
    const first = gi === 1;
    const last = gi === NAV_GROUPS.length - 1;
    return (
      <div key={group} className={`flex flex-col gap-[2px] ${gi === 0 ? '' : first ? 'mt-1' : last ? 'mt-auto pt-5' : 'mt-5'}`} data-nav-group={group}>
        {!collapsed ? (
          meta.caption && (
            <span className="px-2.5 pb-1 text-[10px] uppercase tracking-[0.1em] text-textMuted" title={meta.hint}>
              {meta.caption}
            </span>
          )
        ) : (
          gi > 1 && <span className="mx-3 mb-2 border-t border-ink/[0.08]" aria-hidden />
        )}
        {itemsByGroup(group).map(item => {
          const inside = pathname.startsWith(item.path);
          const tree = !collapsed && inside ? subpagesFor(item.path, pathname, chosenId) : undefined;
          const open = !!tree && !folded[item.path];
          const subs = tree;
          /* the page you are on is the LONGEST nested path the pathname starts with — The board (/compass) is a prefix of every
             Compass page, so the first match lit it on a contract's page and on the Tracker (Noah, 2026-09-13) */
          const activeIdx = subs ? subs.reduce((best, s, i) => (pathname.startsWith(s.path) && (best < 0 || s.path.length > subs[best].path.length) ? i : best), -1) : -1;
          const link = (
            <NavLink
              key={item.path}
              to={item.path}
              data-nav-item={item.path}
              data-nav-current={inside || undefined}
              onMouseEnter={e => showTip(e, item.label)}
              onMouseLeave={hideTip}
              onClick={e => {
                /* inside a section with pages: the row folds and unfolds its tree instead of leaving the page */
                if (!tree) return;
                e.preventDefault();
                setFolded(f => ({ ...f, [item.path]: !f[item.path] }));
              }}
              aria-expanded={tree ? open : undefined}
              className={`group relative flex items-center gap-2.5 h-[30px] rounded-lg text-[13px] transition-colors ${
                collapsed ? 'w-8 ml-[10px] justify-center' : 'px-2.5'
              } ${inside ? 'bg-ink/[0.06] text-textPrimary font-medium' : 'text-textSecondary hover:text-textPrimary hover:bg-ink/[0.04]'}`}
              title={collapsed ? undefined : tree ? `${item.description} — click to ${open ? 'fold' : 'unfold'} its pages` : item.description}
              aria-label={item.label}
            >
              {/* THE PAGE'S GLYPH, as the landing draws it (Noah, 2026-10-03: "change this sidebar inside of the actual
                  terminal to mimic the logos/icons we have on the landing page for each page"): the foil body with the
                  page's one coloured part — the answer to "thirteen inks at once was too much color" (2026-09-09), which
                  the old line icons met by going grey at rest. Settings keeps its line icon, which takes its ink on hover
                  and on the page you are on. */}
              {item.glyph ? (
                <PageGlyph name={item.glyph} size={17} className={`shrink-0 transition-opacity duration-200 ${inside ? 'opacity-100' : 'opacity-80 group-hover:opacity-100'}`} />
              ) : (
                <item.icon
                  className={`w-4 h-4 shrink-0 transition-colors duration-200 ${inside ? 'text-[color:var(--ink)]' : 'text-textMuted group-hover:text-[color:var(--ink)]'}`}
                  strokeWidth={inside ? 2 : 1.75}
                  style={{ '--ink': item.ink } as CSSProperties}
                  data-nav-icon
                />
              )}
              {!collapsed && <span className="truncate">{item.label}</span>}
              {/* THE LOCK (2026-10-10): a room outside the plan held wears a quiet lock, so you know before you press */}
              {!collapsed && access.on && !access.can(item.path) && <Lock className={`${tree ? '' : 'ml-auto'} w-3 h-3 shrink-0 text-textMuted`} aria-hidden data-nav-locked />}
              {/* the fold's chevron — only on a section with pages, only while you are in it */}
              {tree && <ChevronDown className={`ml-auto w-3 h-3 shrink-0 text-textMuted transition-transform duration-200 ${open ? '' : '-rotate-90'}`} aria-hidden data-nav-fold={open ? 'open' : 'folded'} />}
            </NavLink>
          );
          if (!subs) return link;
          /* THE TREE RAIL: a dim track down the nested pages, and a bright
             fill from its top to the page you are on — the completion bar.
             STOP TO STOP (Noah, 2026-10-18, the Dossier fold: "the vertical
             line does not end on the last section of the dropdown, it goes
             slightly past it"): the track used to span the rows' box, so it
             ran half a row past the last page's centre — the dot's stop —
             and half a row above the first. It runs from the first page's
             centre to the last page's; the fill from the first stop to the
             page you are on. */
          const fillTo = activeIdx >= 0 ? activeIdx * SUB_H + SUB_H / 2 : 0;
          return (
            <div key={item.path} className="flex flex-col" data-nav-open={item.path}>
              {link}
              {/* THE FOLD GLIDES (Noah, 2026-09-28: "dropdown and back up should also be smoother"): the house's Fold —
                  the rows' height and opacity over 220ms, nothing mounted or unmounted on a click */}
              <Fold axis="y" open={open} testId="data-nav-tree-fold">
              <div className="relative ml-[23px] mt-1 mb-1" data-nav-tree>
                <span className="absolute left-0 w-px bg-ink/[0.12]" style={{ top: SUB_H / 2, bottom: SUB_H / 2 }} aria-hidden data-nav-track />
                {activeIdx >= 0 && (
                  <>
                    <span
                      data-nav-fill
                      aria-hidden
                      className="absolute -left-px w-[2px] rounded-full transition-[height] duration-300 ease-[cubic-bezier(0.16,1,0.3,1)]"
                      style={{ top: SUB_H / 2, height: Math.max(0, fillTo - SUB_H / 2), background: SILVER, boxShadow: `0 0 6px ${alpha(SILVER, 0.6)}` }}
                    />
                    <span
                      data-nav-fill-dot
                      aria-hidden
                      className="absolute w-[7px] h-[7px] rounded-full transition-[top] duration-300 ease-[cubic-bezier(0.16,1,0.3,1)]"
                      style={{ left: -3.5, top: fillTo - 3.5, background: SILVER, boxShadow: `0 0 8px ${SILVER}` }}
                    />
                  </>
                )}
                <div className="flex flex-col pl-3">
                  {subs.map((s, i) => {
                    const active = i === activeIdx;
                    return (
                      <NavLink
                        key={s.path}
                        to={s.path}
                        data-nav-sub={s.path}
                        style={{ height: SUB_H }}
                        className={`flex items-center px-2 rounded-md text-[12px] transition-colors ${
                          active ? 'text-textPrimary font-medium' : 'text-textSecondary hover:text-textPrimary hover:bg-ink/[0.04]'
                        }`}
                      >
                        {s.label}
                      </NavLink>
                    );
                  })}
                </div>
              </div>
              </Fold>
            </div>
          );
        })}
      </div>
    );
  });
  const [home, ...groups] = groupBlocks;

  const width = collapsed ? SIDENAV_RAIL_W : SIDENAV_W;
  /* ANCHORED TO THE LEFT CORNER THROUGH THE GLIDE (Noah, 2026-09-14: the collapse "jitters
     super fast and leaves its corner really quickly before returning back to it"): the rail's
     rows used to CENTRE their icon (`mx-auto`, `justify-center`) — and the classes flip the
     moment the width starts its 300ms glide, so every icon leapt to the middle of a bar still
     236 wide and slid back as it narrowed. Each row now sets a fixed left inset that centres
     its box in the 52px rail — the mark at 12, a 32px box at 10, the 24px picture at 14 — and
     nothing depends on the width in flight. Opening was always fine: the open rows sit at the
     left by nature. */

  return (
    <>
      {/* THE PANEL, hugging the left edge from tablet width up */}
      <aside
        ref={asideRef}
        onMouseLeave={hideTip}
        onTransitionEnd={e => {
          measure();
          /* Two frames on: the desk's grid measures its new width on the
             frame after the aside settles and lays its items out on the next */
          if (e.target === asideRef.current && e.propertyName === 'width') requestAnimationFrame(() => requestAnimationFrame(endGlide));
        }}
        className="relative hidden md:flex shrink-0 h-full flex-col bg-panel border-r border-ink/[0.07] transition-[width] duration-300 ease-[cubic-bezier(0.16,1,0.3,1)]"
        style={{ width }}
        data-sidenav
        data-collapsed={collapsed || undefined}
      >
        {/* The collapse notch, on the edge */}
        <button
          type="button"
          onClick={toggleCollapsed}
          aria-label={collapsed ? 'Open the sidebar' : 'Collapse the sidebar to icons'}
          title={collapsed ? 'Open the sidebar' : 'Collapse to icons'}
          data-sidenav-toggle
          className="absolute -right-[11px] top-[15px] z-10 w-[22px] h-[22px] rounded-full border border-ink/[0.12] bg-card text-textMuted hover:text-textPrimary hover:border-silver/60 shadow-md shadow-black/50 flex items-center justify-center transition-colors"
        >
          {collapsed ? <ChevronRight className="w-3 h-3" /> : <ChevronLeft className="w-3 h-3" />}
        </button>

        {/* The edge bar — one, on the edge, gliding to the current product */}
        {bar && (
          <span
            data-nav-accent
            aria-hidden
            className="absolute -right-px w-[3px] rounded-full transition-[top] duration-300 ease-[cubic-bezier(0.16,1,0.3,1)]"
            style={{ top: bar.top, height: BAR_H, background: SILVER, boxShadow: `0 0 8px ${alpha(SILVER, 0.4)}` }}
          />
        )}

        {brand}
        <div className={`shrink-0 flex flex-col gap-1 pb-1 ${collapsed ? 'px-0' : 'px-3'}`}>
          {subject}
          <div className={collapsed ? '' : '-mx-1'}>
            {home}
            {alertsRow}
            {watchRow}
          </div>
        </div>
        <nav ref={navRef} className={`flex-1 min-h-0 overflow-y-auto overflow-x-hidden py-1 flex flex-col ${collapsed ? 'px-0' : 'px-2'}`} aria-label="Terminal">
          {groups}
        </nav>
        {/* WHO IS AT THE DESK (2026-09-12): the reader's picture and name at the
            foot, a door to their account; the rail keeps the picture alone */}
        <NavLink
          to={signedOut ? '/signin' : '/settings/account'}
          title={collapsed ? undefined : signedOut ? 'Sign in' : 'Your account'}
          onMouseEnter={e => showTip(e, signedOut ? 'Sign in · your account' : `${profile.name} · @${profile.handle} · your account`)}
          onMouseLeave={hideTip}
          className={({ isActive }) =>
            `shrink-0 flex items-center gap-2.5 border-t border-ink/[0.07] transition-colors ${collapsed ? 'pl-[14px] pr-0 py-2' : 'px-3.5 py-2'} ${
              isActive ? 'bg-ink/[0.05]' : 'hover:bg-ink/[0.03]'
            }`
          }
          data-sidenav-me
        >
          {signedOut ? (
            <span className="shrink-0 inline-flex items-center justify-center w-6 h-6 rounded-full border border-borderSubtle text-textMuted" aria-hidden="true" data-avatar="signed-out">
              <UserRound className="w-3.5 h-3.5" />
            </span>
          ) : (
            <Avatar profile={profile} size={24} />
          )}
          {!collapsed && (
            <span className="min-w-0 flex-1 leading-tight">
              <span className="block truncate text-[12px] font-semibold text-textPrimary">{signedOut ? 'Sign in' : profile.name}</span>
              <span className="block truncate font-mono text-[10px] text-textMuted">{signedOut ? 'or create an account' : `@${profile.handle}`}</span>
            </span>
          )}
        </NavLink>
        {/* THE SIGNATURE (his partner's logo system, 2026-10-03): "slayer:~ $ ● live" — the market's own word, live while
            it is open and closed when it is shut — over the session's own line and the clock. The rail, folded, keeps the
            state's dot. The Sim badge that stood here is the tip's word now; the footer's status line says it on every
            page. */}
        <div
          className={`shrink-0 border-t border-ink/[0.07] bg-ink/[0.02] ${collapsed ? 'pl-[22px] pr-0 py-3.5' : 'px-3.5 py-2.5'}`}
          title={collapsed ? `slayer:~ $ ${marketWord} · ${clock.label} · ${time}` : undefined}
          onMouseEnter={e => showTip(e, `Simulated data · slayer:~ $ ${marketWord} · ${clock.label} · ${time}`)}
          onMouseLeave={hideTip}
          data-sidenav-signature
        >
          {collapsed ? (
            <SignatureDot state={marketWord} className="w-2 h-2" label={`slayer:~ $ ${marketWord}`} />
          ) : (
            <>
              <Signature state={marketWord} rule={false} className="text-[10.5px]" />
              <span className="mt-1.5 flex items-center gap-2 font-mono text-[10px] tnum">
                <span className="min-w-0 truncate text-textSecondary" title={clock.label} data-session-line>
                  {open ? clock.label : clock.label.toLowerCase()}
                </span>
                <span className="ml-auto text-textMuted select-none">{time}</span>
              </span>
            </>
          )}
        </div>
      </aside>

      {/* The rail's hover tip — portalled so no scroller clips it */}
      {tip &&
        collapsed &&
        createPortal(
          <div
            data-nav-tip
            role="tooltip"
            style={{ position: 'fixed', left: tip.x, top: tip.y }}
            className="z-[90] -translate-y-1/2 pointer-events-none whitespace-nowrap px-2 py-1 rounded-md border border-ink/[0.1] bg-card/95 backdrop-blur-md text-[11px] text-textPrimary shadow-lg shadow-black/50 animate-fade-in"
          >
            {tip.label}
          </div>,
          document.body
        )}

      {/* THE PHONE STRIP — the menu, the subject and the search. THE MENU (2026-09-19): the rail is off under 768px and nothing
          stood in for it — the only way between pages on a phone was to know the palette and type a page's name. The house
          mark opens it: the same groups, products and pages as the rail, as a sheet (MobileMenu.tsx). */}
      <div className="md:hidden fixed inset-x-0 top-0 z-40 h-12 flex items-center gap-2.5 px-2.5 bg-canvas/80 backdrop-blur-md border-b border-borderSubtle">
        <button type="button" onClick={() => setMenuOpen(true)} aria-label="Menu" aria-haspopup="dialog" aria-expanded={menuOpen} className="inline-flex items-center justify-center w-9 h-9 rounded-md border border-borderSubtle text-textSecondary" data-mobile-menu-door>
          <Menu className="w-4 h-4" />
        </button>
        <button onClick={onOpenPalette} className="inline-flex items-center gap-2 rounded-md border border-borderMuted bg-chip px-2.5 py-1">
          <CompanyLogo ticker={activeTicker} size={16} />
          <span className="text-[12px] font-semibold text-textPrimary">{activeTicker}</span>
          {marketData && <span className="font-mono text-[11px] tnum text-textPrimary">${marketData.spot.toFixed(2)}</span>}
        </button>
        <button onClick={onOpenPalette} aria-label="Search or jump to…" className="ml-auto p-1.5 rounded-md border border-borderSubtle text-textMuted">
          <Search className="w-3.5 h-3.5" />
        </button>
      </div>
      <MobileMenu open={menuOpen} onClose={closeMenu} />
    </>
  );
};

export default SideNav;
